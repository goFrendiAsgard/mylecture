package gofrendi.tools.gis_d;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {

    Button button_posisi;
    WebView webView_peta;
    double longitude = 0;
    double latitude = 0;

    /**
     * Button click listener
     */
    private class Button_Posisi_Click_Listener implements View.OnClickListener{
        @Override
        public void onClick(android.view.View view){
            // munculkan message google
            Toast.makeText(getBaseContext(),
                    "Longitude : " + longitude + ", Latitude : " + latitude,
                    Toast.LENGTH_LONG).show();
            // buka google
            webView_peta.getSettings().setJavaScriptEnabled(true);
            webView_peta.loadUrl("http://maps.google.com/maps?q="+latitude+","+longitude);
        }

    }

    /**
     * GPS_Listener
     */
    private class GPS_Listener implements LocationListener {

        @Override
        public void onLocationChanged(Location loc) {
            longitude = loc.getLongitude();
            latitude = loc.getLatitude();
        }

        @Override
        public void onProviderDisabled(String provider) {}

        @Override
        public void onProviderEnabled(String provider) {}

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {}
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, new PlaceholderFragment())
                    .commit();
        }

        // asosiasikan variabel button_posisi dgn widget yg ada di tampilan
        button_posisi = (Button) findViewById(R.id.button_posisi);
        button_posisi.setOnClickListener(new Button_Posisi_Click_Listener());

        // asosiasikan variabel webview_peta dgn widget yg ada di tampilan
        webView_peta = (WebView) findViewById(R.id.webView_peta);

        // buat location manager
        LocationManager locationManager = (LocationManager)
                getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 5000, 10, new GPS_Listener());

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {

        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            return rootView;
        }
    }

}
